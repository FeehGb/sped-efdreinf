﻿<?php
/**
 * @name      	CConfig
 * @version   	alfa
 * @copyright	2013 &copy; Softdib
 * @author    	Guilherme Silva
 * @description Classe elaborada para tratar a comunicação do envio e retorno para o erp
 * @TODO 		Fazer tudo
*/

/**
 * @import 
 */ 

/**
 * @class CIntegracaoERP
 */ 
class CIntegracaoERP{

/*
 * Atributos da Classe
 */
	
	public $mensagemErro = "";	
/**
 * @method 	mRetornoInutilizacao
 * @autor 	Guilherme Silva
 * @TODO  	Fazer de tudo
 */
	public function mRetornoInutilizacao($pDiretorio, $dataHora, $pArray=""){
	}
}

?>